
<span class="label label-warning">Analyst Panel</span>
<div class="alert alert-success" role="alert">

<form action="" method="post">

        <label for="inputEmail" class="sr-only">Phone Number</label> 
		<input type="text" id="inputEmail" class="form-control" placeholder="New Phone Number"  name="phone" required autofocus><br />
  <button class="btn btn-lg btn-success btn-block" type="submit" name="edit" >Change</button><br /><br/> 


</form>
<a href="profile.php"><span class="label label-primary">Back</span></a>  or  <a href="logout.php"><span class="label label-danger 	">Log Out</span></a>
	
</div>
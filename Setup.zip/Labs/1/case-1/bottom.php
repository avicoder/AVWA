         </div>
        </div>

    </div><!-- /.container -->
	
	<div id="footer">
  <div class="container">
    <p class="text-muted credit">&copy Paladion Networks Pvt Ltd.<a href="http://paladion.net">Paladion Labs</a> </p>
  </div>
</div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="jquery.js"></script>
    <script src="bootstrap.js"></script>
  

</body></html>
<?php 
echo "<img src='delhi.png' />"
?>
<?php 
echo "<img src='punjab.png' />"
?>	
<?php 
echo "<img src='karnataka.png' />"
?>
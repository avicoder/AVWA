<?php 
echo "<img src='maharashtra.png' />"
?>
<?php
include('top.php');
?>
<br/><br/><br/><br/><br/><br/>        <br/><br/>  <p><center><img src="https://bo0om.ru/wp-content/themes/mystique/images/bug.gif" /></center>	<center><i class="fa fa-code fa-5x "></i></p></center>
 
 <?php 
 include('bottom.php')
 ?>